package com.example.tvremote

import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream

/** Protobuf mínimo escrito à mão (sem dependências). */
object Proto {
    fun varint(v: Long): ByteArray {
        val o = ByteArrayOutputStream()
        var x = v
        while (x > 0x7FL) { o.write(((x and 0x7FL) or 0x80L).toInt()); x = x ushr 7 }
        o.write(x.toInt())
        return o.toByteArray()
    }
    fun fVarint(f: Int, v: Long): ByteArray = varint((f shl 3).toLong()) + varint(v)
    fun fBytes(f: Int, b: ByteArray): ByteArray = varint(((f shl 3) or 2).toLong()) + varint(b.size.toLong()) + b
    fun fStr(f: Int, s: String): ByteArray = fBytes(f, s.toByteArray())
    fun frame(m: ByteArray): ByteArray = varint(m.size.toLong()) + m

    /** Campos de nível superior: número -> Long (varint) ou ByteArray (submensagem/texto). */
    fun parse(b: ByteArray): Map<Int, Any> {
        val m = HashMap<Int, Any>()
        var i = 0
        fun rv(): Long {
            var r = 0L
            var s = 0
            while (true) {
                val x = b[i++].toInt()
                r = r or ((x and 0x7F).toLong() shl s)
                if ((x and 0x80) == 0) break
                s += 7
            }
            return r
        }
        while (i < b.size) {
            val tag = rv().toInt()
            val f = tag ushr 3
            when (tag and 7) {
                0 -> m[f] = rv()
                1 -> i += 8
                5 -> i += 4
                2 -> { val n = rv().toInt(); m[f] = b.copyOfRange(i, i + n); i += n }
                else -> throw IOException("Mensagem inválida")
            }
        }
        return m
    }

    fun readFrame(inp: InputStream): ByteArray {
        var len = 0
        var shift = 0
        while (true) {
            val x = inp.read()
            if (x < 0) throw EOFException("TV fechou a conexão")
            len = len or ((x and 0x7F) shl shift)
            if ((x and 0x80) == 0) break
            shift += 7
        }
        val buf = ByteArray(len)
        var off = 0
        while (off < len) {
            val n = inp.read(buf, off, len - off)
            if (n < 0) throw EOFException("TV fechou a conexão")
            off += n
        }
        return buf
    }
}
