package com.example.tvremote

import android.content.Context
import java.util.concurrent.Executors
import javax.net.ssl.SSLSocket

/** Conexão de controle (porta 6466). */
class RemoteConn(
    private val ctx: Context,
    private val host: String,
    private val log: (String) -> Unit,
    private val onState: (Boolean) -> Unit
) {
    private var sock: SSLSocket? = null
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var closed = false

    private fun device(): ByteArray =
        Proto.fStr(1, "Android") + Proto.fStr(2, "Google") + Proto.fVarint(3, 1) +
            Proto.fStr(4, "1") + Proto.fStr(5, "com.example.tvremote") + Proto.fStr(6, "1.0.0")

    fun connect() {
        Thread {
            try {
                val s = Tls.socket(ctx, host, 6466)
                sock = s
                val inp = s.inputStream
                while (!closed) {
                    val m = Proto.parse(Proto.readFrame(inp))
                    when {
                        m.containsKey(1) -> send(Proto.fBytes(1, Proto.fVarint(1, 622) + Proto.fBytes(2, device())))
                        m.containsKey(2) -> { send(Proto.fBytes(2, Proto.fVarint(1, 622))); log("Pronto para usar"); onState(true) }
                        m.containsKey(8) -> {
                            val v = (Proto.parse(m[8] as ByteArray)[1] as? Long) ?: 0L
                            send(Proto.fBytes(9, Proto.fVarint(1, v)))
                        }
                        m.containsKey(3) -> log("A TV informou um erro")
                    }
                }
            } catch (e: Exception) {
                if (!closed) log("Conexão encerrada: ${e.message}. Se for a primeira vez, toque em Parear.")
            }
            onState(false)
        }.start()
    }

    private fun send(b: ByteArray) {
        if (closed) return
        exec.execute {
            try {
                sock?.outputStream?.let { it.write(Proto.frame(b)); it.flush() }
            } catch (e: Exception) { log("Falha ao enviar: ${e.message}") }
        }
    }

    /** Aperta e solta uma tecla (códigos de tecla do Android). */
    fun key(code: Int) = send(Proto.fBytes(10, Proto.fVarint(1, code.toLong()) + Proto.fVarint(2, 3)))

    fun close() {
        closed = true
        try { sock?.close() } catch (_: Exception) {}
        exec.shutdown()
    }
}
