package com.example.tvremote

import android.content.Context
import java.io.IOException
import java.math.BigInteger
import java.security.MessageDigest
import java.security.interfaces.RSAPublicKey
import java.security.cert.X509Certificate

/** Pareamento com a TV (porta 6467). A TV mostra um código de 6 caracteres. */
class Pairing(private val ctx: Context, private val host: String, private val log: (String) -> Unit) {

    private fun hex(n: BigInteger): ByteArray {
        var h = n.toString(16)
        if (h.length % 2 == 1) h = "0$h"
        return ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    /** askCode: bloqueia até o usuário digitar o código; devolve null se cancelar. */
    fun start(askCode: () -> String?): Boolean {
        Tls.socket(ctx, host, 6467).use { s ->
            val inp = s.inputStream
            val out = s.outputStream

            fun send(field: Int, body: ByteArray) {
                val m = Proto.fVarint(1, 2) + Proto.fVarint(2, 200) + Proto.fBytes(field, body)
                out.write(Proto.frame(m)); out.flush()
            }
            fun recv(expect: Int) {
                val m = Proto.parse(Proto.readFrame(inp))
                val st = (m[2] as? Long) ?: 0L
                if (st != 200L) throw IOException("A TV recusou (status $st)")
                if (!m.containsKey(expect)) throw IOException("Resposta inesperada da TV: ${m.keys}")
            }

            send(10, Proto.fStr(1, "atvremote") + Proto.fStr(2, "Controle TV")); recv(11)
            val enc = Proto.fVarint(1, 3) + Proto.fVarint(2, 6) // hexadecimal, 6 símbolos
            send(20, Proto.fBytes(1, enc) + Proto.fVarint(3, 1)); recv(20)
            send(30, Proto.fBytes(1, enc) + Proto.fVarint(2, 1)); recv(31)

            val code = askCode() ?: return false
            if (code.length != 6) throw IOException("O código tem 6 caracteres")
            val cb = ByteArray(3) { code.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

            val cp = Tls.clientCert(ctx).publicKey as RSAPublicKey
            val sp = (s.session.peerCertificates[0] as X509Certificate).publicKey as RSAPublicKey
            val md = MessageDigest.getInstance("SHA-256")
            md.update(hex(cp.modulus)); md.update(hex(cp.publicExponent))
            md.update(hex(sp.modulus)); md.update(hex(sp.publicExponent))
            md.update(cb.copyOfRange(1, 3))
            val digest = md.digest()
            if (digest[0] != cb[0]) throw IOException("Código incorreto")

            send(40, Proto.fBytes(1, digest)); recv(41)
            return true
        }
    }
}
