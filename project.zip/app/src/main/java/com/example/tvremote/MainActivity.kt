package com.example.tvremote

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.LinkedBlockingQueue

class MainActivity : Activity() {
    private lateinit var ip: EditText
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var tvList: LinearLayout
    private var conn: RemoteConn? = null
    private var disc: Discovery? = null
    private val found = HashSet<String>()
    private val codeQ = LinkedBlockingQueue<String>()
    private val logBuf = StringBuilder()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun log(s: String) = runOnUiThread {
        logBuf.append(s).append('\n')
        if (logBuf.length > 1500) logBuf.delete(0, logBuf.length - 1500)
        logView.text = logBuf.toString()
    }

    private fun btn(t: String, h: Int = 64, onClick: () -> Unit): Button = Button(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 18f; isAllCaps = false
        background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xFF232A33.toInt()) }
        setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); onClick() }
        layoutParams = LinearLayout.LayoutParams(0, dp(h), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
    }

    private fun key(t: String, code: Int) = btn(t) {
        val c = conn
        if (c == null) log("Toque em Conectar primeiro") else c.key(code)
    }

    private fun spacer() = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(64), 1f) }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        ip = EditText(this).apply {
            hint = "IP da TV (ex: 192.168.0.20)"
            setText(prefs.getString("ip", ""))
            setTextColor(Color.WHITE); setHintTextColor(0xFF8A94A0.toInt())
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        status = TextView(this).apply {
            text = "○ Desconectado"; setTextColor(0xFFE57373.toInt()); textSize = 16f; gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        tvList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        logView = TextView(this).apply { setTextColor(0xFF8A94A0.toInt()); textSize = 12f }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
            addView(ip)
            addView(row(btn("Buscar TV na rede", 52) { startDiscovery() }))
            addView(tvList)
            addView(row(btn("Parear", 52) { startPair() }, btn("Conectar", 52) { connect() }))
            addView(status)
            addView(row(spacer(), key("▲", 19), spacer()))
            addView(row(key("◀", 21), key("OK", 23), key("▶", 22)))
            addView(row(spacer(), key("▼", 20), spacer()))
            addView(row(key("Voltar", 4), key("Home", 3), key("Menu", 82)))
            addView(row(key("Vol −", 25), key("Mudo", 164), key("Vol +", 24)))
            addView(row(key("⏯", 85), key("Power", 26)))
            addView(logView)
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF101418.toInt())
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        startDiscovery()
    }

    private fun startDiscovery() {
        disc?.stop()
        found.clear()
        tvList.removeAllViews()
        disc = Discovery(this) { n, a -> onTv(n, a) }
        try { disc?.start(); log("Procurando TVs na rede...") } catch (e: Exception) { log("Busca falhou: ${e.message}") }
    }

    private fun onTv(name: String, addr: String) = runOnUiThread {
        if (!found.add(addr)) return@runOnUiThread
        log("TV encontrada: $name ($addr)")
        tvList.addView(row(btn("$name · $addr", 52) { ip.setText(addr); log("IP definido: $addr") }))
        if (found.size == 1) ip.setText(addr)
    }

    private fun host(): String? {
        val h = ip.text.toString().trim()
        if (h.isEmpty()) { log("Digite o IP da TV"); return null }
        getSharedPreferences("p", MODE_PRIVATE).edit().putString("ip", h).apply()
        return h
    }

    private fun askCode() {
        val et = EditText(this).apply {
            hint = "Código de 6 caracteres"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        AlertDialog.Builder(this).setTitle("Código que aparece na TV").setView(et).setCancelable(false)
            .setPositiveButton("OK") { _, _ -> codeQ.put(et.text.toString().trim()) }
            .setNegativeButton("Cancelar") { _, _ -> codeQ.put("") }
            .show()
    }

    private fun startPair() {
        val h = host() ?: return
        codeQ.clear()
        Thread {
            try {
                log("Pareando com $h... olhe o código na TV")
                val ok = Pairing(this, h) { s -> log(s) }.start {
                    runOnUiThread { askCode() }
                    codeQ.take().ifEmpty { null }
                }
                log(if (ok) "Pareado! Agora toque em Conectar" else "Pareamento cancelado")
            } catch (e: Exception) {
                log("Erro no pareamento: ${e.message}")
            }
        }.start()
    }

    private fun connect() {
        val h = host() ?: return
        conn?.close()
        conn = RemoteConn(this, h, { s -> log(s) }) { ok ->
            runOnUiThread {
                status.text = if (ok) "● Conectado" else "○ Desconectado"
                status.setTextColor(if (ok) 0xFF4CAF50.toInt() else 0xFFE57373.toInt())
            }
        }
        conn?.connect()
        log("Conectando...")
    }

    override fun onDestroy() { conn?.close(); disc?.stop(); super.onDestroy() }
}
